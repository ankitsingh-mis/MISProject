
  # Forecast Calculator Design

  This is a code bundle for Forecast Calculator Design. The original project is available at https://www.figma.com/design/faShucw55sBUClJYOrTvDA/Forecast-Calculator-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  